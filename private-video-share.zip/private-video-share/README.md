# Private Video Share

A tiny, private website for exactly two people to upload and watch videos together.
No one else can get in — there's a login screen with two accounts you set yourself.

## What's inside
- `server.js` — the whole backend (login, upload, video streaming)
- `views/` — the login page and the gallery page
- `public/style.css` — styling
- `uploads/` — where video files get stored (created automatically)

## 1. Run it on your own computer first (recommended)

You need [Node.js](https://nodejs.org) installed (version 18 or newer).

```bash
cd private-video-share
npm install
cp .env.example .env
```

Open `.env` in a text editor and set:
- `SESSION_SECRET` — any long random string
- `USER1_NAME` / `USER1_PASS` — the first person's login
- `USER2_NAME` / `USER2_PASS` — the second person's login

Then start it:

```bash
npm start
```

Visit **http://localhost:3000** — you should see the login screen. Sign in with either account, upload a video, and it'll appear for both accounts.

## 2. Put it online so both of you can reach it from anywhere

The app itself is ready to deploy as-is. The one thing to think about is **where uploaded videos are stored** — most free hosting wipes local disk files whenever the app restarts or redeploys. Two solid options:

### Option A — Railway (simplest, ~$5/month covers this easily)
1. Push this folder to a **private** GitHub repo.
2. Go to [railway.app](https://railway.app), create a new project, and deploy from that repo.
3. In the Railway project settings, add all the variables from your `.env` file (Variables tab).
4. Add a **Volume** and mount it at `/app/uploads` — this makes uploaded videos persist across restarts/redeploys.
5. Railway will give you a public URL (like `yourapp.up.railway.app`) — that's the site both of you use.

### Option B — Render
1. Push to a private GitHub repo, create a new **Web Service** on [render.com](https://render.com) pointing at it.
2. Build command: `npm install` — Start command: `npm start`.
3. Add your `.env` variables under Environment.
4. Add a **Persistent Disk** mounted at `/opt/render/project/src/uploads` (Render's disks require a paid instance type — the cheapest one is fine for two people).

### Option C — Your own server / VPS
Copy the folder over, run `npm install && npm start` (ideally under a process manager like `pm2`), and put it behind a domain with HTTPS (e.g. via [Caddy](https://caddyserver.com) or [nginx + certbot](https://certbot.eff.org)). This avoids the "ephemeral disk" issue entirely since it's a real machine.

> ⚠️ Always deploy with **HTTPS** in front (Railway and Render both give you this automatically). Never run this on plain HTTP over the public internet — your login password would be sent unencrypted.

## Notes & limits
- Upload limit is set to 2GB per video (`server.js`, search for `fileSize`) — raise or lower as you like.
- There's no "forgot password" flow — if you lose a password, just update it in your environment variables and restart the app.
- This is built for **two trusted people**, not the general public — there's no signup page, and video links only work while logged in.
- Want more accounts later, or cloud storage (e.g. so disk space is never a worry)? Both are straightforward additions — just ask.
