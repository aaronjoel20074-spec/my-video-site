require('dotenv').config();
const express = require('express');
const session = require('express-session');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const UPLOAD_DIR = path.join(__dirname, 'uploads');
const META_FILE = path.join(UPLOAD_DIR, '_meta.json');

if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(META_FILE)) fs.writeFileSync(META_FILE, '[]');

// ---- basic config sanity check ----
const REQUIRED_ENV = ['SESSION_SECRET', 'USER1_NAME', 'USER1_PASS', 'USER2_NAME', 'USER2_PASS'];
for (const key of REQUIRED_ENV) {
  if (!process.env[key]) {
    console.error(`Missing required environment variable: ${key}. Copy .env.example to .env and fill it in.`);
    process.exit(1);
  }
}

const USERS = {
  [process.env.USER1_NAME]: process.env.USER1_PASS,
  [process.env.USER2_NAME]: process.env.USER2_PASS,
};

// ---- middleware ----
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
    secure: process.env.NODE_ENV === 'production',
  },
}));

function requireAuth(req, res, next) {
  if (req.session && req.session.user) return next();
  if (req.path.startsWith('/api/')) return res.status(401).json({ error: 'Not logged in' });
  return res.redirect('/login');
}

// ---- helpers for the tiny JSON "database" of video metadata ----
function readMeta() {
  return JSON.parse(fs.readFileSync(META_FILE, 'utf8'));
}
function writeMeta(data) {
  fs.writeFileSync(META_FILE, JSON.stringify(data, null, 2));
}

// ---- auth routes ----
app.get('/login', (req, res) => {
  if (req.session.user) return res.redirect('/');
  res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  if (USERS[username] && USERS[username] === password) {
    req.session.user = username;
    return res.json({ ok: true });
  }
  res.status(401).json({ error: 'Wrong username or password' });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get('/api/me', (req, res) => {
  res.json({ user: req.session.user || null });
});

// ---- main page (protected) ----
app.get('/', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'gallery.html'));
});

// ---- upload (protected) ----
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const id = crypto.randomBytes(8).toString('hex');
    const ext = path.extname(file.originalname) || '.mp4';
    cb(null, `${id}${ext}`);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 2 * 1024 * 1024 * 1024 }, // 2GB per file, adjust as needed
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith('video/')) {
      return cb(new Error('Only video files are allowed'));
    }
    cb(null, true);
  },
});

app.post('/api/upload', requireAuth, (req, res) => {
  upload.single('video')(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message });
    if (!req.file) return res.status(400).json({ error: 'No file received' });

    const meta = readMeta();
    const entry = {
      id: req.file.filename,
      originalName: req.file.originalname,
      uploadedBy: req.session.user,
      uploadedAt: new Date().toISOString(),
      size: req.file.size,
    };
    meta.unshift(entry);
    writeMeta(meta);
    res.json({ ok: true, video: entry });
  });
});

// ---- list videos (protected) ----
app.get('/api/videos', requireAuth, (req, res) => {
  res.json(readMeta());
});

// ---- delete a video (protected, uploader or the other user can both manage) ----
app.delete('/api/videos/:id', requireAuth, (req, res) => {
  const meta = readMeta();
  const idx = meta.findIndex(v => v.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });

  const filePath = path.join(UPLOAD_DIR, meta[idx].id);
  fs.unlink(filePath, () => {}); // ignore error if already gone
  meta.splice(idx, 1);
  writeMeta(meta);
  res.json({ ok: true });
});

// ---- stream video with range support (protected) ----
app.get('/api/stream/:id', requireAuth, (req, res) => {
  const meta = readMeta();
  const video = meta.find(v => v.id === req.params.id);
  if (!video) return res.status(404).end();

  const filePath = path.join(UPLOAD_DIR, video.id);
  if (!fs.existsSync(filePath)) return res.status(404).end();

  const stat = fs.statSync(filePath);
  const fileSize = stat.size;
  const range = req.headers.range;

  const mimeType = path.extname(filePath) === '.mov' ? 'video/quicktime' : 'video/mp4';

  if (range) {
    const parts = range.replace(/bytes=/, '').split('-');
    const start = parseInt(parts[0], 10);
    const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
    const chunkSize = end - start + 1;
    const stream = fs.createReadStream(filePath, { start, end });
    res.writeHead(206, {
      'Content-Range': `bytes ${start}-${end}/${fileSize}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': chunkSize,
      'Content-Type': mimeType,
    });
    stream.pipe(res);
  } else {
    res.writeHead(200, {
      'Content-Length': fileSize,
      'Content-Type': mimeType,
    });
    fs.createReadStream(filePath).pipe(res);
  }
});

app.listen(PORT, () => {
  console.log(`Private video share running on http://localhost:${PORT}`);
});
